import React, { useState, useRef } from "react";
import { motion, useMotionValue, useTransform } from "motion/react";
import { clsx, type ClassValue } from "clsx";
import { twMerge } from "tailwind-merge";

function cn(...inputs: ClassValue[]) {
  return twMerge(clsx(inputs));
}

interface Slider3DProps {
  value?: number;
  onChange?: (value: number) => void;
  min?: number;
  max?: number;
  step?: number;
  showValue?: boolean;
  className?: string;
}

export function Slider3D({ 
  value: controlledValue,
  onChange,
  min = 0,
  max = 100,
  step = 1,
  showValue = false,
  className 
}: Slider3DProps) {
  const [internalValue, setInternalValue] = useState(min);
  const trackRef = useRef<HTMLDivElement>(null);
  const isDragging = useRef(false);

  const isControlled = controlledValue !== undefined;
  const value = isControlled ? controlledValue : internalValue;
  const percentage = ((value - min) / (max - min)) * 100;

  const updateValue = (clientX: number) => {
    if (!trackRef.current) return;

    const rect = trackRef.current.getBoundingClientRect();
    const clickPosition = clientX - rect.left;
    const percentage = Math.max(0, Math.min(1, clickPosition / rect.width));
    const rawValue = min + percentage * (max - min);
    const steppedValue = Math.round(rawValue / step) * step;
    const clampedValue = Math.max(min, Math.min(max, steppedValue));

    if (isControlled) {
      onChange?.(clampedValue);
    } else {
      setInternalValue(clampedValue);
      onChange?.(clampedValue);
    }
  };

  const handleMouseDown = (e: React.MouseEvent) => {
    isDragging.current = true;
    updateValue(e.clientX);
  };

  const handleMouseMove = (e: MouseEvent) => {
    if (isDragging.current) {
      updateValue(e.clientX);
    }
  };

  const handleMouseUp = () => {
    isDragging.current = false;
  };

  React.useEffect(() => {
    document.addEventListener('mousemove', handleMouseMove);
    document.addEventListener('mouseup', handleMouseUp);
    return () => {
      document.removeEventListener('mousemove', handleMouseMove);
      document.removeEventListener('mouseup', handleMouseUp);
    };
  }, []);

  return (
    <div className={cn("w-full", className)}>
      <div className="perspective-[800px]">
        <div 
          ref={trackRef}
          onMouseDown={handleMouseDown}
          className="relative h-3 cursor-pointer py-1"
          style={{
            transformStyle: "preserve-3d",
          }}
        >
          {/* Track - recessed groove */}
          <div className={cn(
            "relative h-2 rounded-full bg-gradient-to-b from-gray-300 to-gray-200 dark:from-neutral-800 dark:to-neutral-900",
            "shadow-[inset_0_2px_4px_rgba(0,0,0,0.2),0_1px_1px_rgba(0,0,0,0.05)]",
            "border border-gray-400/20 dark:border-neutral-700"
          )}>
            {/* Track depth */}
            <div 
              className="absolute inset-0 rounded-full bg-gray-400 dark:bg-neutral-950"
              style={{
                transform: "translateZ(-3px)",
              }}
            />

            {/* Fill - raised portion */}
            <motion.div
              className="absolute left-0 top-0 h-full rounded-full overflow-hidden"
              style={{ 
                width: `${percentage}%`,
                transformStyle: "preserve-3d",
              }}
            >
              {/* Fill depth */}
              <div 
                className="absolute inset-0 rounded-full bg-blue-700"
                style={{
                  transform: "translateZ(-2px)",
                }}
              />
              
              {/* Fill surface */}
              <div 
                className={cn(
                  "absolute inset-0 rounded-full",
                  "bg-gradient-to-b from-blue-400 to-blue-500",
                  "shadow-[0_0_10px_rgba(59,130,246,0.5),inset_0_1px_0_rgba(255,255,255,0.3)]"
                )}
                style={{
                  transform: "translateZ(1px)",
                }}
              >
                {/* Shimmer */}
                <motion.div
                  className="absolute inset-0 rounded-full bg-gradient-to-r from-transparent via-white/30 to-transparent"
                  animate={{
                    x: ["-100%", "200%"],
                  }}
                  transition={{
                    duration: 2,
                    repeat: Infinity,
                    ease: "linear",
                  }}
                />
              </div>
            </motion.div>
          </div>

          {/* Thumb - 3D ball */}
          <motion.div
            className="absolute top-1/2 -translate-y-1/2"
            style={{ 
              left: `${percentage}%`,
              x: "-50%",
              transformStyle: "preserve-3d",
            }}
            whileHover={{ scale: 1.1 }}
            whileTap={{ scale: 0.95 }}
          >
            {/* Thumb shadow */}
            <div 
              className="absolute inset-0 w-5 h-5 rounded-full bg-gray-400 dark:bg-neutral-700 blur-sm"
              style={{
                transform: "translateZ(-3px) translateY(2px)",
              }}
            />

            {/* Thumb sphere */}
            <div 
              className={cn(
                "relative w-5 h-5 rounded-full",
                "bg-gradient-to-br from-white via-gray-100 to-gray-200",
                "shadow-[0_2px_8px_rgba(0,0,0,0.2),inset_0_1px_0_rgba(255,255,255,0.8),inset_-1px_-1px_2px_rgba(0,0,0,0.1)]",
                "border border-gray-300"
              )}
              style={{
                transform: "translateZ(6px)",
              }}
            >
              {/* Highlight sphere */}
              <div className="absolute top-1 left-1 w-2 h-2 rounded-full bg-white/80 blur-[0.5px]" />
            </div>
          </motion.div>
        </div>
      </div>

      {showValue && (
        <div className="text-xs font-semibold text-center mt-2 text-muted-foreground">
          {value}
        </div>
      )}
    </div>
  );
}
