import React from "react";
import { motion } from "motion/react";
import { clsx, type ClassValue } from "clsx";
import { twMerge } from "tailwind-merge";

function cn(...inputs: ClassValue[]) {
  return twMerge(clsx(inputs));
}

interface Button3DProps {
  children: React.ReactNode;
  variant?: "primary" | "secondary" | "destructive";
  size?: "sm" | "md" | "lg";
  onClick?: () => void;
  disabled?: boolean;
  className?: string;
}

export function Button3D({ 
  children, 
  variant = "primary", 
  size = "md",
  onClick,
  disabled = false,
  className 
}: Button3DProps) {
  const variants = {
    primary: {
      top: "bg-gradient-to-b from-blue-400 to-blue-500",
      side: "bg-blue-700",
      glow: "shadow-[0_0_20px_rgba(59,130,246,0.5)]"
    },
    secondary: {
      top: "bg-gradient-to-b from-gray-300 to-gray-400 dark:from-neutral-600 dark:to-neutral-700",
      side: "bg-gray-600 dark:bg-neutral-900",
      glow: "shadow-[0_0_15px_rgba(107,114,128,0.3)]"
    },
    destructive: {
      top: "bg-gradient-to-b from-red-400 to-red-500",
      side: "bg-red-700",
      glow: "shadow-[0_0_20px_rgba(239,68,68,0.5)]"
    },
  };

  const sizes = {
    sm: "px-4 py-2 text-sm",
    md: "px-6 py-3 text-base",
    lg: "px-8 py-4 text-lg",
  };

  const depthSizes = {
    sm: 3,
    md: 4,
    lg: 6,
  };

  const depth = depthSizes[size];

  return (
    <div className={cn("inline-block perspective-[1000px]", className)}>
      <motion.button
        onClick={onClick}
        disabled={disabled}
        whileHover={{ y: -2, transition: { duration: 0.1 } }}
        whileTap={{ y: depth - 1 }}
        className="relative"
        style={{
          transformStyle: "preserve-3d",
        }}
      >
        {/* Button Side/Depth */}
        <motion.div
          className={cn(
            "absolute inset-0 rounded-lg",
            variants[variant].side
          )}
          style={{
            transform: `translateZ(-${depth}px)`,
          }}
        />
        
        {/* Button Sides (left, right, bottom) - creates the 3D edge */}
        <div 
          className={cn("absolute inset-0 rounded-lg", variants[variant].side)}
          style={{
            transform: `translateY(${depth}px)`,
            height: `${depth}px`,
            top: '100%',
          }}
        />

        {/* Button Top Face */}
        <motion.div
          whileTap={{ 
            boxShadow: "inset 0 2px 8px rgba(0,0,0,0.3)",
          }}
          className={cn(
            "relative rounded-lg font-semibold text-white transition-all duration-100",
            "shadow-[inset_0_1px_0_rgba(255,255,255,0.3),inset_0_-1px_0_rgba(0,0,0,0.2)]",
            variants[variant].top,
            variants[variant].glow,
            sizes[size],
            disabled && "opacity-50 cursor-not-allowed",
          )}
          style={{
            transform: `translateZ(${depth}px)`,
            transformStyle: "preserve-3d",
          }}
        >
          <span className="relative z-10 drop-shadow-[0_1px_2px_rgba(0,0,0,0.3)]">
            {children}
          </span>
        </motion.div>
      </motion.button>
    </div>
  );
}

// Tilt Card Component with REAL depth
interface Card3DProps {
  children: React.ReactNode;
  className?: string;
}

export function Card3D({ children, className }: Card3DProps) {
  const [rotateX, setRotateX] = React.useState(0);
  const [rotateY, setRotateY] = React.useState(0);
  const cardRef = React.useRef<HTMLDivElement>(null);

  const handleMouseMove = (e: React.MouseEvent<HTMLDivElement>) => {
    if (!cardRef.current) return;
    
    const rect = cardRef.current.getBoundingClientRect();
    const centerX = rect.left + rect.width / 2;
    const centerY = rect.top + rect.height / 2;
    
    const mouseX = e.clientX - centerX;
    const mouseY = e.clientY - centerY;
    
    const rotateXValue = (mouseY / (rect.height / 2)) * -15;
    const rotateYValue = (mouseX / (rect.width / 2)) * 15;
    
    setRotateX(rotateXValue);
    setRotateY(rotateYValue);
  };

  const handleMouseLeave = () => {
    setRotateX(0);
    setRotateY(0);
  };

  return (
    <div className="perspective-[1500px]">
      <motion.div
        ref={cardRef}
        onMouseMove={handleMouseMove}
        onMouseLeave={handleMouseLeave}
        animate={{ rotateX, rotateY }}
        transition={{ type: "spring", stiffness: 300, damping: 30 }}
        className={cn(
          "relative rounded-2xl bg-gradient-to-br from-white to-gray-50 dark:from-neutral-900 dark:to-neutral-950",
          "border-2 border-gray-200 dark:border-neutral-800",
          "shadow-[0_20px_50px_rgba(0,0,0,0.15),inset_0_1px_0_rgba(255,255,255,0.1)]",
          className
        )}
        style={{
          transformStyle: "preserve-3d",
        }}
      >
        {/* Card depth/thickness */}
        <div 
          className="absolute inset-0 rounded-2xl bg-gradient-to-b from-gray-300 to-gray-400 dark:from-neutral-800 dark:to-neutral-900"
          style={{
            transform: "translateZ(-8px)",
            zIndex: -1,
          }}
        />
        
        {/* Content layer floating above */}
        <div 
          className="p-6"
          style={{ 
            transform: "translateZ(30px)",
            transformStyle: "preserve-3d",
          }}
        >
          {children}
        </div>

        {/* Shine/reflection effect */}
        <div 
          className="absolute inset-0 rounded-2xl bg-gradient-to-br from-white/20 via-transparent to-transparent pointer-events-none"
          style={{
            transform: "translateZ(1px)",
          }}
        />
      </motion.div>
    </div>
  );
}