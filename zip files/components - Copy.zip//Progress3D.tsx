import React from "react";
import { motion } from "motion/react";
import { clsx, type ClassValue } from "clsx";
import { twMerge } from "tailwind-merge";

function cn(...inputs: ClassValue[]) {
  return twMerge(clsx(inputs));
}

interface Progress3DProps {
  value: number;
  max?: number;
  showValue?: boolean;
  variant?: "default" | "success" | "warning" | "danger";
  className?: string;
}

export function Progress3D({ 
  value, 
  max = 100,
  showValue = false,
  variant = "default",
  className 
}: Progress3DProps) {
  const percentage = Math.min(Math.max((value / max) * 100, 0), 100);

  const variants = {
    default: {
      gradient: "from-blue-400 via-blue-500 to-blue-600",
      glow: "shadow-[0_0_20px_rgba(59,130,246,0.6),inset_0_1px_1px_rgba(255,255,255,0.3)]",
      side: "bg-blue-700"
    },
    success: {
      gradient: "from-green-400 via-green-500 to-green-600",
      glow: "shadow-[0_0_20px_rgba(34,197,94,0.6),inset_0_1px_1px_rgba(255,255,255,0.3)]",
      side: "bg-green-700"
    },
    warning: {
      gradient: "from-yellow-400 via-yellow-500 to-yellow-600",
      glow: "shadow-[0_0_20px_rgba(234,179,8,0.6),inset_0_1px_1px_rgba(255,255,255,0.3)]",
      side: "bg-yellow-700"
    },
    danger: {
      gradient: "from-red-400 via-red-500 to-red-600",
      glow: "shadow-[0_0_20px_rgba(239,68,68,0.6),inset_0_1px_1px_rgba(255,255,255,0.3)]",
      side: "bg-red-700"
    },
  };

  return (
    <div className={cn("w-full", className)}>
      <div className="perspective-[800px]">
        <div 
          className="relative h-6 rounded-full overflow-visible"
          style={{
            transformStyle: "preserve-3d",
          }}
        >
          {/* Track/Container - inset/recessed */}
          <div className={cn(
            "relative h-full rounded-full bg-gradient-to-b from-gray-300 to-gray-200 dark:from-neutral-800 dark:to-neutral-900",
            "shadow-[inset_0_2px_6px_rgba(0,0,0,0.2),0_1px_2px_rgba(0,0,0,0.05)]",
            "border border-gray-400/30 dark:border-neutral-700"
          )}>
            {/* Track depth */}
            <div 
              className="absolute inset-0 rounded-full bg-gray-400 dark:bg-neutral-950"
              style={{
                transform: "translateZ(-4px)",
              }}
            />

            {/* Progress fill - raised cylinder */}
            <motion.div
              className="relative h-full rounded-full overflow-visible"
              initial={{ width: 0 }}
              animate={{ width: `${percentage}%` }}
              transition={{
                type: "spring",
                stiffness: 100,
                damping: 20,
              }}
              style={{
                transformStyle: "preserve-3d",
              }}
            >
              {percentage > 0 && (
                <>
                  {/* Fill side/depth */}
                  <div 
                    className={cn("absolute inset-0 rounded-full", variants[variant].side)}
                    style={{
                      transform: "translateZ(-3px)",
                    }}
                  />
                  
                  {/* Fill top surface - cylindrical gradient */}
                  <div 
                    className={cn(
                      "absolute inset-0 rounded-full bg-gradient-to-b",
                      variants[variant].gradient,
                      variants[variant].glow
                    )}
                    style={{
                      transform: "translateZ(2px)",
                    }}
                  >
                    {/* Cylindrical highlight */}
                    <div className="absolute inset-0 rounded-full bg-gradient-to-b from-white/40 via-white/10 to-transparent" 
                      style={{
                        clipPath: "ellipse(100% 30% at 50% 20%)",
                      }}
                    />
                    
                    {/* Shimmer animation */}
                    <motion.div
                      className="absolute inset-0 rounded-full bg-gradient-to-r from-transparent via-white/40 to-transparent"
                      animate={{
                        x: ["-100%", "200%"],
                      }}
                      transition={{
                        duration: 2,
                        repeat: Infinity,
                        ease: "linear",
                      }}
                    />
                  </div>

                  {/* End cap for cylinder effect */}
                  {percentage < 100 && (
                    <div 
                      className={cn(
                        "absolute right-0 top-0 w-2 h-full rounded-r-full",
                        variants[variant].side
                      )}
                      style={{
                        transform: "translateX(1px) translateZ(0px)",
                      }}
                    />
                  )}
                </>
              )}
            </motion.div>

            {/* Track shine */}
            <div className="absolute inset-0 rounded-full bg-gradient-to-b from-white/5 via-transparent to-black/5 pointer-events-none" />
          </div>
        </div>
      </div>
      
      {showValue && (
        <div className="text-xs font-semibold text-center mt-2 text-muted-foreground">
          {Math.round(percentage)}%
        </div>
      )}
    </div>
  );
}
