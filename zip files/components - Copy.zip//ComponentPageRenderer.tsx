import React, { useState } from "react";
import { ChevronRight } from "lucide-react";
import { 
  ButtonShowcase, 
  CardShowcase, 
  SwitchShowcase, 
  CheckboxShowcase, 
  RadioShowcase, 
  DialogShowcase,
  BadgeShowcase,
  AccordionShowcase,
  AvatarShowcase,
  ProgressShowcase,
  SkeletonShowcase,
  ToastShowcase,
  HoverCardShowcase,
  SheetShowcase,
  InputShowcase,
  SliderShowcase,
  TooltipShowcase
} from "./ComponentShowcase";

interface ComponentConfig {
  name: string;
  description: string;
  showcase: React.ComponentType;
}

const COMPONENT_MAP: Record<string, ComponentConfig> = {
  "button": {
    name: "3D Button",
    description: "A button with physical press depth. The button has visible edges that disappear as it's pressed down.",
    showcase: ButtonShowcase,
  },
  "card": {
    name: "3D Card",
    description: "An interactive card with tilt effect that follows mouse cursor with parallax depth.",
    showcase: CardShowcase,
  },
  "switch": {
    name: "3D Switch",
    description: "A physical toggle switch that rocks left/right with 3D rotation.",
    showcase: SwitchShowcase,
  },
  "checkbox": {
    name: "3D Checkbox",
    description: "A recessed cube that fills with a 3D checkmark popping out on the Z-axis.",
    showcase: CheckboxShowcase,
  },
  "radio-group": {
    name: "3D Radio Group",
    description: "Convex buttons that become concave (depressed) when selected with shadow inversion.",
    showcase: RadioShowcase,
  },
  "dialog": {
    name: "3D Dialog",
    description: "A dialog that flies in from the screen with scale and rotation animations.",
    showcase: DialogShowcase,
  },
  "badge": {
    name: "3D Badge",
    description: "A floating pill that slowly rotates or shimmers with depth.",
    showcase: BadgeShowcase,
  },
  "accordion": {
    name: "3D Accordion",
    description: "Panels that unfold like a folded piece of paper with transform origin animations.",
    showcase: AccordionShowcase,
  },
  "avatar": {
    name: "3D Avatar",
    description: "Profile picture with a floating status indicator orb orbiting with Z-axis manipulation.",
    showcase: AvatarShowcase,
  },
  "progress": {
    name: "3D Progress",
    description: "A tube or bar filling up with liquid/solid volume and shimmer effects.",
    showcase: ProgressShowcase,
  },
  "skeleton": {
    name: "3D Skeleton",
    description: "A shimmering block with depth (like a thick tile) for loading states.",
    showcase: SkeletonShowcase,
  },
  "toast": {
    name: "3D Toast",
    description: "Toasts that stack physically on top of each other like a deck of cards.",
    showcase: ToastShowcase,
  },
  "hover-card": {
    name: "3D Hover Card",
    description: "A card that floats significantly higher than the trigger element with translateZ.",
    showcase: HoverCardShowcase,
  },
  "sheet": {
    name: "3D Sheet",
    description: "A physical layer sliding over with separation via shadow depth and Z-index.",
    showcase: SheetShowcase,
  },
  "input": {
    name: "3D Input",
    description: "A text input field with a subtle 3D effect.",
    showcase: InputShowcase,
  },
  "slider": {
    name: "3D Slider",
    description: "A slider with a 3D handle that moves along a track.",
    showcase: SliderShowcase,
  },
  "tooltip": {
    name: "3D Tooltip",
    description: "A tooltip that appears with a 3D animation when hovering over an element.",
    showcase: TooltipShowcase,
  },
};

interface ComponentPageRendererProps {
  componentId: string;
  onNavigate: (page: string) => void;
}

export function ComponentPageRenderer({ componentId, onNavigate }: ComponentPageRendererProps) {
  const [viewMode, setViewMode] = useState<'preview' | 'code'>('preview');
  const config = COMPONENT_MAP[componentId];

  if (!config) {
    return null;
  }

  const ShowcaseComponent = config.showcase;

  return (
    <div className="space-y-8 animate-in fade-in slide-in-from-bottom-4 duration-500">
      <div className="space-y-2">
        <div className="flex items-center gap-2 text-sm text-muted-foreground mb-4">
          <span className="hover:text-foreground cursor-pointer" onClick={() => onNavigate('components-index')}>Components</span>
          <ChevronRight size={14} />
          <span className="text-foreground font-medium">{config.name}</span>
        </div>
        <h1 className="text-3xl font-bold tracking-tight">{config.name}</h1>
        <p className="text-lg text-muted-foreground">
          {config.description}
        </p>
      </div>
      
      <div className="border border-border rounded-xl overflow-hidden bg-background shadow-sm">
        <div className="flex items-center justify-between px-4 py-3 border-b border-border bg-muted/30">
          <div className="flex space-x-1 bg-muted/50 p-1 rounded-lg">
            <button 
              onClick={() => setViewMode('preview')}
              className={`px-3 py-1 rounded-md text-sm font-medium transition-all ${viewMode === 'preview' ? "bg-background shadow-sm text-foreground" : "text-muted-foreground hover:text-foreground"}`}
            >
              Preview
            </button>
            <button 
              onClick={() => setViewMode('code')}
              className={`px-3 py-1 rounded-md text-sm font-medium transition-all ${viewMode === 'code' ? "bg-background shadow-sm text-foreground" : "text-muted-foreground hover:text-foreground"}`}
            >
              Code
            </button>
          </div>
        </div>
        <div className="relative min-h-[350px] flex items-center justify-center p-8">
          {viewMode === 'preview' ? (
            <ShowcaseComponent />
          ) : (
            <div className="w-full">
              <div className="rounded-lg bg-neutral-950 dark:bg-black border border-neutral-800 p-4">
                <pre className="text-xs sm:text-sm font-mono text-neutral-300 leading-relaxed overflow-x-auto">
                  <code>{`// Copy component from /components/${componentId.split('-').map(s => s.charAt(0).toUpperCase() + s.slice(1)).join('')}3D.tsx`}</code>
                </pre>
              </div>
            </div>
          )}
        </div>
      </div>
      
      <div className="space-y-4">
        <h2 className="text-xl font-semibold">Technical Details</h2>
        <div className="space-y-2 text-sm text-muted-foreground">
          <p><strong>3D Concept:</strong> {config.description}</p>
          <p><strong>Animation Engine:</strong> Motion (Framer Motion) with spring physics</p>
          <p><strong>Styling:</strong> Tailwind CSS with CSS 3D transforms</p>
        </div>
      </div>
    </div>
  );
}

export function isComponentImplemented(componentId: string): boolean {
  return componentId in COMPONENT_MAP;
}