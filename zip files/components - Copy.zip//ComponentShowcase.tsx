import React, { useState } from "react";
import { Button3D, Card3D } from "./Button3D";
import { Switch3D } from "./Switch3D";
import { Checkbox3D } from "./Checkbox3D";
import { RadioGroup3D } from "./RadioGroup3D";
import { Dialog3D } from "./Dialog3D";
import { Badge3D, BadgeShimmer } from "./Badge3D";
import { Accordion3D } from "./Accordion3D";
import { Avatar3D } from "./Avatar3D";
import { Progress3D } from "./Progress3D";
import { Skeleton3D, SkeletonCard, SkeletonAvatar } from "./Skeleton3D";
import { ToastContainer3D, useToast3D } from "./Toast3D";
import { HoverCard3D } from "./HoverCard3D";
import { Sheet3D } from "./Sheet3D";
import { Input3D } from "./Input3D";
import { Slider3D } from "./Slider3D";
import { Tooltip3D } from "./Tooltip3D";
import { Mail, Search, User } from "lucide-react";

export function ButtonShowcase() {
  return (
    <div className="flex flex-wrap gap-4 items-center">
      <Button3D>Default Button</Button3D>
      <Button3D variant="secondary">Secondary</Button3D>
      <Button3D variant="destructive">Destructive</Button3D>
      <Button3D size="sm">Small</Button3D>
      <Button3D size="lg">Large</Button3D>
    </div>
  );
}

export function CardShowcase() {
  return (
    <div className="max-w-md mx-auto">
      <Card3D>
        <div className="space-y-4">
          <h3 className="text-2xl font-bold">Interactive 3D Card</h3>
          <p className="text-muted-foreground">
            Move your mouse around to see the 3D tilt effect. The card rotates based on your cursor position.
          </p>
          <div className="flex gap-2">
            <Button3D size="sm">Action</Button3D>
            <Button3D size="sm" variant="secondary">Cancel</Button3D>
          </div>
        </div>
      </Card3D>
    </div>
  );
}

export function SwitchShowcase() {
  const [checked, setChecked] = useState(false);
  
  return (
    <div className="flex flex-col gap-6">
      <div className="flex items-center gap-4">
        <Switch3D checked={checked} onChange={setChecked} />
        <span className="text-sm">Toggle me!</span>
      </div>
      <div className="flex items-center gap-4">
        <Switch3D />
        <span className="text-sm">Uncontrolled switch</span>
      </div>
      <div className="flex items-center gap-4">
        <Switch3D disabled />
        <span className="text-sm text-muted-foreground">Disabled</span>
      </div>
    </div>
  );
}

export function CheckboxShowcase() {
  const [checked, setChecked] = useState(false);
  
  return (
    <div className="flex flex-col gap-4">
      <Checkbox3D 
        label="Controlled checkbox" 
        checked={checked} 
        onChange={setChecked} 
      />
      <Checkbox3D label="Uncontrolled checkbox" />
      <Checkbox3D label="Accept terms and conditions" />
      <Checkbox3D label="Disabled" disabled />
    </div>
  );
}

export function RadioShowcase() {
  const [value, setValue] = useState("option1");
  
  const options = [
    { value: "option1", label: "First Option" },
    { value: "option2", label: "Second Option" },
    { value: "option3", label: "Third Option" },
  ];
  
  return (
    <div className="space-y-4">
      <p className="text-sm text-muted-foreground">Selected: {value}</p>
      <RadioGroup3D 
        options={options}
        value={value}
        onChange={setValue}
      />
    </div>
  );
}

export function DialogShowcase() {
  const [open, setOpen] = useState(false);
  
  return (
    <div>
      <Button3D onClick={() => setOpen(true)}>
        Open Dialog
      </Button3D>
      
      <Dialog3D
        open={open}
        onOpenChange={setOpen}
        title="3D Dialog"
        description="This dialog flies in from the screen with a beautiful 3D animation."
      >
        <div className="space-y-4 pt-4">
          <p className="text-sm">
            Notice how the dialog doesn't just fade in - it scales and rotates from the Z-axis, creating a physically realistic entrance.
          </p>
          <div className="flex justify-end gap-2">
            <Button3D variant="secondary" size="sm" onClick={() => setOpen(false)}>
              Cancel
            </Button3D>
            <Button3D size="sm" onClick={() => setOpen(false)}>
              Confirm
            </Button3D>
          </div>
        </div>
      </Dialog3D>
    </div>
  );
}

export function BadgeShowcase() {
  return (
    <div className="flex flex-wrap gap-4 items-center">
      <Badge3D>Default</Badge3D>
      <Badge3D variant="secondary">Secondary</Badge3D>
      <Badge3D variant="destructive">Destructive</Badge3D>
      <Badge3D variant="outline">Outline</Badge3D>
      <Badge3D animate={false}>No Animation</Badge3D>
      <BadgeShimmer>Shimmer</BadgeShimmer>
    </div>
  );
}

export function AccordionShowcase() {
  const items = [
    {
      id: "1",
      title: "What is 3D design?",
      content: "3D design uses depth (Z-axis) to communicate hierarchy and interactivity. It's not about making everything spin, but using physical metaphors to make interfaces more intuitive."
    },
    {
      id: "2",
      title: "How does it work?",
      content: "We use CSS 3D transforms (transform-style: preserve-3d) and Motion spring physics to create realistic depth effects without heavy WebGL."
    },
    {
      id: "3",
      title: "Is it performant?",
      content: "Yes! By using CSS transforms instead of WebGL, we keep the bundle size small and performance high, even on lower-end devices."
    },
  ];
  
  return (
    <div className="max-w-2xl">
      <Accordion3D items={items} />
    </div>
  );
}

export function AvatarShowcase() {
  return (
    <div className="flex flex-wrap gap-6 items-center">
      <Avatar3D size="sm" status="online" />
      <Avatar3D size="md" status="away" src="https://raw.githubusercontent.com/Tarikul-Islam-Anik/Animated-Fluent-Emojis/master/Emojis/Smilies/Grinning%20Face.png" />
      <Avatar3D size="lg" status="busy" />
      <Avatar3D status="offline" />
    </div>
  );
}

export function ProgressShowcase() {
  const [progress, setProgress] = useState(0);

  React.useEffect(() => {
    const interval = setInterval(() => {
      setProgress(prev => (prev >= 100 ? 0 : prev + 10));
    }, 1000);
    return () => clearInterval(interval);
  }, []);

  return (
    <div className="space-y-6">
      <Progress3D value={progress} showValue />
      <Progress3D value={75} variant="success" showValue />
      <Progress3D value={50} variant="warning" showValue />
      <Progress3D value={25} variant="danger" showValue />
    </div>
  );
}

export function SkeletonShowcase() {
  return (
    <div className="space-y-6">
      <div className="space-y-2">
        <Skeleton3D variant="text" width="60%" />
        <Skeleton3D variant="text" width="80%" />
        <Skeleton3D variant="text" width="40%" />
      </div>
      <div className="flex gap-4">
        <Skeleton3D variant="circle" width="48px" height="48px" />
        <Skeleton3D variant="rectangular" height="48px" className="flex-1" />
      </div>
      <SkeletonCard />
      <SkeletonAvatar />
    </div>
  );
}

export function ToastShowcase() {
  const { toasts, addToast, dismissToast } = useToast3D();
  
  return (
    <div>
      <div className="flex flex-wrap gap-2">
        <Button3D size="sm" onClick={() => addToast({
          title: "Default Toast",
          description: "This is a default toast message",
        })}>
          Default
        </Button3D>
        <Button3D size="sm" onClick={() => addToast({
          title: "Success!",
          description: "Your changes have been saved",
          variant: "success"
        })}>
          Success
        </Button3D>
        <Button3D size="sm" onClick={() => addToast({
          title: "Error",
          description: "Something went wrong",
          variant: "error"
        })}>
          Error
        </Button3D>
        <Button3D size="sm" onClick={() => addToast({
          title: "Warning",
          description: "Please review your input",
          variant: "warning"
        })}>
          Warning
        </Button3D>
      </div>
      
      <ToastContainer3D toasts={toasts} onDismiss={dismissToast} />
    </div>
  );
}

export function HoverCardShowcase() {
  return (
    <div className="flex gap-4">
      <HoverCard3D
        trigger={<Button3D size="sm">Hover me!</Button3D>}
        content={
          <div className="space-y-2">
            <h4 className="font-semibold">3D Hover Card</h4>
            <p className="text-sm text-muted-foreground">
              This card floats above the trigger element with realistic depth and shadows.
            </p>
          </div>
        }
      />
      <HoverCard3D
        trigger={
          <Avatar3D 
            status="online" 
            src="https://raw.githubusercontent.com/Tarikul-Islam-Anik/Animated-Fluent-Emojis/master/Emojis/Smilies/Robot.png" 
          />
        }
        content={
          <div className="space-y-2">
            <h4 className="font-semibold">Robot User</h4>
            <p className="text-sm text-muted-foreground">Status: Online</p>
            <p className="text-xs text-muted-foreground">
              A 3D avatar with floating status indicator
            </p>
          </div>
        }
      />
    </div>
  );
}

export function SheetShowcase() {
  const [open, setOpen] = useState(false);
  const [side, setSide] = useState<"left" | "right" | "top" | "bottom">("right");
  
  return (
    <div>
      <div className="flex flex-wrap gap-2 mb-4">
        <Button3D size="sm" onClick={() => { setSide("left"); setOpen(true); }}>
          Left
        </Button3D>
        <Button3D size="sm" onClick={() => { setSide("right"); setOpen(true); }}>
          Right
        </Button3D>
        <Button3D size="sm" onClick={() => { setSide("top"); setOpen(true); }}>
          Top
        </Button3D>
        <Button3D size="sm" onClick={() => { setSide("bottom"); setOpen(true); }}>
          Bottom
        </Button3D>
      </div>
      
      <Sheet3D
        open={open}
        onOpenChange={setOpen}
        side={side}
        title="3D Sheet"
        description="A physical layer sliding over with depth separation via shadow."
      >
        <div className="space-y-4">
          <p className="text-sm">
            The sheet slides in from the {side} with a realistic shadow, creating a sense of physical layering.
          </p>
          <div className="flex justify-end gap-2">
            <Button3D variant="secondary" size="sm" onClick={() => setOpen(false)}>
              Close
            </Button3D>
          </div>
        </div>
      </Sheet3D>
    </div>
  );
}

export function InputShowcase() {
  return (
    <div className="space-y-4 max-w-md">
      <Input3D placeholder="Enter your email" label="Email" />
      <Input3D placeholder="Search..." icon={<Search size={18} />} />
      <Input3D 
        placeholder="Password" 
        type="password" 
        label="Password"
      />
      <Input3D 
        placeholder="Invalid input" 
        label="Username"
        error="This field is required"
      />
      <Input3D placeholder="Disabled" disabled />
    </div>
  );
}

export function SliderShowcase() {
  const [value, setValue] = useState(50);
  
  return (
    <div className="space-y-6 max-w-md">
      <div>
        <p className="text-sm text-muted-foreground mb-2">Value: {value}</p>
        <Slider3D 
          value={value}
          onChange={setValue}
          showValue
        />
      </div>
      <Slider3D 
        value={75}
        showValue
      />
      <Slider3D 
        min={0}
        max={10}
        step={1}
        value={5}
        showValue
      />
    </div>
  );
}

export function TooltipShowcase() {
  return (
    <div className="flex flex-wrap gap-4 items-center">
      <Tooltip3D content="Top tooltip" side="top">
        <Button3D size="sm">Top</Button3D>
      </Tooltip3D>
      <Tooltip3D content="Bottom tooltip" side="bottom">
        <Button3D size="sm">Bottom</Button3D>
      </Tooltip3D>
      <Tooltip3D content="Left tooltip" side="left">
        <Button3D size="sm">Left</Button3D>
      </Tooltip3D>
      <Tooltip3D content="Right tooltip" side="right">
        <Button3D size="sm">Right</Button3D>
      </Tooltip3D>
      <Tooltip3D content="This is a longer tooltip with more information">
        <Button3D variant="secondary" size="sm">Hover for details</Button3D>
      </Tooltip3D>
    </div>
  );
}