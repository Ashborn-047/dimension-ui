import React from "react";
import { motion } from "motion/react";
import { clsx, type ClassValue } from "clsx";
import { twMerge } from "tailwind-merge";

function cn(...inputs: ClassValue[]) {
  return twMerge(clsx(inputs));
}

interface Badge3DProps {
  children: React.ReactNode;
  variant?: "default" | "secondary" | "destructive" | "outline";
  animate?: boolean;
  className?: string;
}

export function Badge3D({ 
  children, 
  variant = "default",
  animate = true,
  className 
}: Badge3DProps) {
  const variants = {
    default: "bg-primary text-primary-foreground border-primary/50",
    secondary: "bg-secondary text-secondary-foreground border-secondary",
    destructive: "bg-destructive text-destructive-foreground border-destructive/50",
    outline: "bg-background text-foreground border-border",
  };

  return (
    <motion.span
      animate={animate ? {
        rotateY: [0, 360],
        transition: {
          duration: 8,
          repeat: Infinity,
          ease: "linear",
        }
      } : {}}
      className={cn(
        "inline-flex items-center px-2.5 py-0.5 rounded-full text-xs font-semibold border shadow-md",
        variants[variant],
        className
      )}
      style={{
        transformStyle: "preserve-3d",
      }}
    >
      <span className="relative z-10">{children}</span>
    </motion.span>
  );
}

// Shimmer variant
export function BadgeShimmer({ 
  children, 
  className 
}: { children: React.ReactNode; className?: string }) {
  return (
    <motion.span
      className={cn(
        "inline-flex items-center px-2.5 py-0.5 rounded-full text-xs font-semibold border bg-gradient-to-r from-blue-500 via-purple-500 to-blue-500 text-white border-purple-400/50 shadow-lg bg-[length:200%_100%]",
        className
      )}
      animate={{
        backgroundPosition: ["0% 0%", "100% 0%"],
      }}
      transition={{
        duration: 3,
        repeat: Infinity,
        ease: "linear",
      }}
      style={{
        transformStyle: "preserve-3d",
      }}
    >
      <span className="relative z-10">{children}</span>
    </motion.span>
  );
}
