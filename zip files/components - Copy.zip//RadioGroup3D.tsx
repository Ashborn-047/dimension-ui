import React, { useState } from "react";
import { motion } from "motion/react";
import { clsx, type ClassValue } from "clsx";
import { twMerge } from "tailwind-merge";

function cn(...inputs: ClassValue[]) {
  return twMerge(clsx(inputs));
}

interface RadioOption {
  value: string;
  label: string;
}

interface RadioGroup3DProps {
  options: RadioOption[];
  value?: string;
  onChange?: (value: string) => void;
  disabled?: boolean;
  className?: string;
}

export function RadioGroup3D({ 
  options,
  value: controlledValue, 
  onChange,
  disabled = false,
  className 
}: RadioGroup3DProps) {
  const [internalValue, setInternalValue] = useState(options[0]?.value || "");
  
  const isControlled = controlledValue !== undefined;
  const selectedValue = isControlled ? controlledValue : internalValue;

  const handleChange = (value: string) => {
    if (disabled) return;
    
    if (isControlled) {
      onChange?.(value);
    } else {
      setInternalValue(value);
      onChange?.(value);
    }
  };

  return (
    <div className={cn("flex flex-col gap-3", className)}>
      {options.map((option) => {
        const isSelected = selectedValue === option.value;
        
        return (
          <label
            key={option.value}
            className={cn(
              "inline-flex items-center gap-3 cursor-pointer",
              disabled && "opacity-50 cursor-not-allowed"
            )}
          >
            <div className="perspective-[500px]">
              <motion.button
                type="button"
                onClick={() => handleChange(option.value)}
                disabled={disabled}
                className={cn(
                  "relative w-6 h-6 rounded-full border-2 transition-all duration-200 focus:outline-none focus:ring-2 focus:ring-primary focus:ring-offset-2",
                  isSelected 
                    ? "bg-blue-500 border-blue-600" 
                    : "bg-white dark:bg-neutral-800 border-neutral-300 dark:border-neutral-600"
                )}
                style={{
                  transformStyle: "preserve-3d",
                  boxShadow: isSelected 
                    ? "inset 0 3px 6px rgba(0,0,0,0.3)" 
                    : "0 2px 4px rgba(0,0,0,0.1)",
                }}
                whileTap={{ scale: 0.95 }}
              >
                <motion.div
                  initial={{ scale: 0 }}
                  animate={{ 
                    scale: isSelected ? 1 : 0,
                    z: isSelected ? -10 : 0,
                  }}
                  transition={{
                    type: "spring",
                    stiffness: 500,
                    damping: 25,
                  }}
                  className="absolute inset-0 flex items-center justify-center"
                  style={{
                    transformStyle: "preserve-3d",
                  }}
                >
                  <div className="w-2.5 h-2.5 rounded-full bg-white" />
                </motion.div>
              </motion.button>
            </div>
            <span className="text-sm font-medium">{option.label}</span>
          </label>
        );
      })}
    </div>
  );
}
